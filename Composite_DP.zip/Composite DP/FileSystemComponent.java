public interface FileSystemComponent {
    public int fs();
}
